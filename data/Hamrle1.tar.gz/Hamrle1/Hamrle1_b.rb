Hamrle/Hamrle1_b                                                       |1199b   
             3             1             1             1
ira                       32             1             2             0
(40I2)          (26I3)          (20I4)              
 1 3
  3  5
  10 -10
